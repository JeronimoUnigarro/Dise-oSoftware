package PackageNombre;

public class Main {

	public static void main(String[] args) {
		  Direccion direccion = new Direccion("", "", "", "", "", "", "");

		     System.out.println("Ingrese los datos del nombre:");
		     direccion.nuevoNombre();

		     System.out.println("\nIngrese los datos de la dirección:");
		     direccion.nuevaDireccion();

		     System.out.println("\nDatos ingresados:");
		     direccion.mostrar();
		 }
		}