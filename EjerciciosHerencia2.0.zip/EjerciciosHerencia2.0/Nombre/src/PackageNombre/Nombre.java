package PackageNombre;
import java.util.Scanner;

class Nombre {
 protected String nombre;
 protected String primerApellido;
 protected String segundoApellido;


 public Nombre(String nombre, String primerApellido, String segundoApellido) {
     this.nombre = nombre;
     this.primerApellido = primerApellido;
     this.segundoApellido = segundoApellido;
 }

 
 public void leerNombre() {
     Scanner scanner = new Scanner(System.in);
     System.out.print("Ingrese el nombre: ");
     this.nombre = scanner.nextLine();
     System.out.print("Ingrese el primer apellido: ");
     this.primerApellido = scanner.nextLine();
     System.out.print("Ingrese el segundo apellido: ");
     this.segundoApellido = scanner.nextLine();
 }

 
 public void mostrar() {
     System.out.println("Nombre completo: " + nombre + " " + primerApellido + " " + segundoApellido);
 }
}




