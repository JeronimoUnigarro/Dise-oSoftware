package PackageNombre;
import java.util.Scanner;

class Direccion extends Nombre {
	 private String calle;
	 private String ciudad;
	 private String provincia;
	 private String codigoPostal;
	 
	 public Direccion(String nombre, String primerApellido, String segundoApellido,
	                  String calle, String ciudad, String provincia, String codigoPostal) {
	     super(nombre, primerApellido, segundoApellido);
	     this.calle = calle;
	     this.ciudad = ciudad;
	     this.provincia = provincia;
	     this.codigoPostal = codigoPostal;
	 }

	 public void nuevaDireccion() {
	     Scanner scanner = new Scanner(System.in);
	     System.out.print("Ingrese la calle: ");
	     this.calle = scanner.nextLine();
	     System.out.print("Ingrese la ciudad: ");
	     this.ciudad = scanner.nextLine();
	     System.out.print("Ingrese la provincia: ");
	     this.provincia = scanner.nextLine();
	     System.out.print("Ingrese el código postal: ");
	     this.codigoPostal = scanner.nextLine();
	 }
 
	 public void nuevoNombre() {
	     leerNombre();
	 }
	 
	 @Override
	 public void mostrar() {
	     super.mostrar();
	     System.out.println("Dirección: " + calle + ", " + ciudad + ", " + provincia + ", " + codigoPostal);
	 }
	}