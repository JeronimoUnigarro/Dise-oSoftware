package PackagePublicacion;

class Libro extends Publicacion {
	 private int numeroPaginas;
	 private int añoPublicacion;

	 
	 public Libro(String titulo, float precio, int numeroPaginas, int añoPublicacion) {
	     super(titulo, precio);
	     this.numeroPaginas = numeroPaginas;
	     this.añoPublicacion = añoPublicacion;
	 }


	 @Override
	 public void mostrar() {
	     super.mostrar();
	     System.out.println("Número de páginas: " + numeroPaginas);
	     System.out.println("Año de publicación: " + añoPublicacion);
	 }
	}

