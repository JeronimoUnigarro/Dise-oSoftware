package PackageCirculo;

import java.util.Scanner;

class CilindroHueco extends Cilindro {
    private double radioInterno;

    
    public CilindroHueco(double radio, double altura, double radioInterno) {
        super(radio, altura);
        this.radioInterno = radioInterno;
    }

   
    public CilindroHueco() {
        super();
        this.radioInterno = 0;
    }

    
    public void leerRadioInterno() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el radio interno del cilindro hueco: ");
        this.radioInterno = scanner.nextDouble();
    }

    
    @Override
    public double volumen() {
        return Math.PI * (Math.pow(radio, 2) - Math.pow(radioInterno, 2)) * altura;
    }

   
    @Override
    public double area() {
        return 2 * Math.PI * altura * (radio + radioInterno) + super.area();
    }
}