package PackageCirculo;

public class Main {
    public static void main(String[] args) {
       
        Cilindro cilindro = new Cilindro();
        cilindro.leerRadio();
        cilindro.leerAltura();
        
      
        System.out.println("\nCilindro:");
        System.out.println("Área: " + cilindro.area());
        System.out.println("Volumen: " + cilindro.volumen());
        System.out.println("Circunferencia: " + cilindro.circunferencia());

      
        CilindroHueco cilindroHueco = new CilindroHueco();
        cilindroHueco.leerRadio();
        cilindroHueco.leerAltura();
        cilindroHueco.leerRadioInterno();

      
        System.out.println("\nCilindro Hueco:");
        System.out.println("Área: " + cilindroHueco.area());
        System.out.println("Volumen: " + cilindroHueco.volumen());
        System.out.println("Circunferencia: " + cilindroHueco.circunferencia());
    }
}