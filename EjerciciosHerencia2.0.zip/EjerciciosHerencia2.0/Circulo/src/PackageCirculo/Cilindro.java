package PackageCirculo;

import java.util.Scanner;

class Cilindro extends Circulo {
    protected double altura;

   
    public Cilindro(double radio, double altura) {
        super(radio);
        this.altura = altura;
    }

    
    public Cilindro() {
        super();
        this.altura = 0;
    }
 
    public void leerAltura() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese la altura del cilindro: ");
        this.altura = scanner.nextDouble();
    }

  
    public double area() {
        return 2 * super.area() + circunferencia() * altura;
    }

 
    public double volumen() {
        return super.area() * altura;
    }
}