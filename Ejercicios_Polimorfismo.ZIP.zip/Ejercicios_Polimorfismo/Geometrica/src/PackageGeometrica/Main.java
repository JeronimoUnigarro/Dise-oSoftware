package PackageGeometrica;
import java.util.Scanner;

public class Main {

	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        int opcion;

	        do {
	            System.out.println("Seleccione la figura geométrica para calcular el área y perímetro:");
	            System.out.println("1. Círculo");
	            System.out.println("2. Cuadrado");
	            System.out.println("3. Rectángulo");
	            System.out.println("4. Triángulo");
	            System.out.println("5. Cubo");
	            System.out.println("6. Salir");
	            System.out.print("Opción: ");
	            opcion = scanner.nextInt();

	            switch (opcion) {
	                case 1: 
	                    System.out.print("Ingrese el radio del círculo: ");
	                    int radio = scanner.nextInt();
	                    Circulo circulo = new Circulo(radio);
	                    System.out.println("Área del círculo: " + circulo.getArea());
	                    System.out.println("Perímetro del círculo: " + circulo.getPerimetro());
	                    break;

	                case 2: 
	                    System.out.print("Ingrese el lado del cuadrado: ");
	                    int lado = scanner.nextInt();
	                    Cuadrado cuadrado = new Cuadrado(lado);
	                    System.out.println("Área del cuadrado: " + cuadrado.getArea());
	                    System.out.println("Perímetro del cuadrado: " + cuadrado.getPerimetro());
	                    break;

	                case 3: 
	                    System.out.print("Ingrese el largo del rectángulo: ");
	                    int largo = scanner.nextInt();
	                    System.out.print("Ingrese el ancho del rectángulo: ");
	                    int ancho = scanner.nextInt();
	                    Rectangulo rectangulo = new Rectangulo(largo, ancho);
	                    System.out.println("Área del rectángulo: " + rectangulo.getArea());
	                    System.out.println("Perímetro del rectángulo: " + rectangulo.getPerimetro());
	                    break;

	                case 4: 
	                    System.out.print("Ingrese la base del triángulo: ");
	                    int base = scanner.nextInt();
	                    System.out.print("Ingrese la altura del triángulo: ");
	                    int altura = scanner.nextInt();
	                    Triangulo triangulo = new Triangulo(base, altura);
	                    System.out.println("Área del triángulo: " + triangulo.getArea());
	                    System.out.println("Perímetro del triángulo (aproximado): " + triangulo.getPerimetro());
	                    break;

	                case 5: 
	                    System.out.print("Ingrese el lado del cubo: ");
	                    int ladoCubo = scanner.nextInt();
	                    Cubo cubo = new Cubo(ladoCubo);
	                    System.out.println("Área del cubo: " + cubo.getArea());
	                    break;

	                case 6:
	                    System.out.println("Saliendo del programa...");
	                    break;

	                default:
	                    System.out.println("Opción no válida. Intente nuevamente.");
	            }
	            System.out.println(); 
	        } while (opcion != 6);

	        scanner.close();
	    }
	}