/**
 * 
 */
/**
 * 
 */
module Geometrica {
}