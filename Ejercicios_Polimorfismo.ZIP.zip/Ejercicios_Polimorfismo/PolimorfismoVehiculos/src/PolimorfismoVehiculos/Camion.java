package PolimorfismoVehiculos;


class Camion extends Vehiculo {
 private Remolque remolque;

 public Camion(String matricula) {
     super(matricula);
     this.remolque = null; 
 }

 public void ponRemolque(Remolque remolque) {
     this.remolque = remolque;
 }

 public void quitaRemolque() {
     this.remolque = null;
 }

 @Override
 public void acelerar(int kmh) {
     super.acelerar(kmh);
     if (this.remolque != null && this.velocidad > 100) {
         System.out.println("¡El camión va demasiado rápido con el remolque!");
     }
 }

 @Override
 public String toString() {
     return super.toString() + (remolque != null ? ", " + remolque.toString() : ", Sin remolque");
 }
}
