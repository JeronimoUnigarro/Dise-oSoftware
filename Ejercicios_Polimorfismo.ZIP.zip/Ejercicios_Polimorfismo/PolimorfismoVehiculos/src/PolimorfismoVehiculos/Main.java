package PolimorfismoVehiculos;
import java.util.Scanner;

public class Main {

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	      
	        System.out.print("Ingrese la matrícula del coche: ");
	        String matriculaCoche = scanner.nextLine();
	        System.out.print("Ingrese el número de puertas del coche: ");
	        int numeroPuertas = scanner.nextInt();
	        Coche coche = new Coche(matriculaCoche, numeroPuertas);

	       
	        System.out.println(coche.toString());
	        System.out.print("¿Cuántos km/h desea acelerar el coche? ");
	        int acelerarCoche = scanner.nextInt();
	        coche.acelerar(acelerarCoche);
	        System.out.println("Después de acelerar: " + coche.toString());

	       
	        System.out.print("\nIngrese la matrícula del camión: ");
	        scanner.nextLine(); 
	        String matriculaCamion = scanner.nextLine();
	        Camion camion = new Camion(matriculaCamion);

	       
	        System.out.print("¿Desea añadir un remolque al camión? (si/no): ");
	        String respuestaRemolque = scanner.nextLine();
	        if (respuestaRemolque.equalsIgnoreCase("si")) {
	            System.out.print("Ingrese el peso del remolque (kg): ");
	            int pesoRemolque = scanner.nextInt();
	            Remolque remolque = new Remolque(pesoRemolque);
	            camion.ponRemolque(remolque);
	        }

	        
	        System.out.println(camion.toString());
	        System.out.print("¿Cuántos km/h desea acelerar el camión? ");
	        int acelerarCamion = scanner.nextInt();
	        camion.acelerar(acelerarCamion);
	        System.out.println("Después de acelerar: " + camion.toString());

	        scanner.close();
	    }
	}