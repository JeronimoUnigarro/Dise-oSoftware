package PolimorfismoVehiculos;

class Coche extends Vehiculo {
 private int numeroPuertas;

 public Coche(String matricula, int numeroPuertas) {
     super(matricula);
     this.numeroPuertas = numeroPuertas;
 }

 public int getNumeroPuertas() {
     return numeroPuertas;
 }

 @Override
 public String toString() {
     return super.toString() + ", Coche [numeroPuertas=" + numeroPuertas + "]";
 }
}