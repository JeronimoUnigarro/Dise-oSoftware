package PolimorfismoVehiculos;

class Vehiculo {
 protected String matricula;
 protected int velocidad;

 public Vehiculo(String matricula) {
     this.matricula = matricula;
     this.velocidad = 0;
 }

 public void acelerar(int kmh) {
     this.velocidad += kmh;
 }

 @Override
 public String toString() {
     return "Vehiculo [matricula=" + matricula + ", velocidad=" + velocidad + " km/h]";
 }
}